# Webflow Cloud Login App

This is a basic login/register backend demo for Webflow Cloud using JavaScript.

## Endpoints

- `POST /api/register` - Registers a new user
- `POST /api/login` - Logs in a user

## Data Store

Users are stored using Webflow Cloud's internal key-value store.